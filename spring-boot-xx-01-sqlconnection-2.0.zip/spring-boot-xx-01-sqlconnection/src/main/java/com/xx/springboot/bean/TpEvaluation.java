package com.xx.springboot.bean;

public class TpEvaluation {

    private Integer e_id;
    private Integer e_fid;
    private Integer e_uid;
    private Integer e_wid;
    private Integer e_allrating;
    private String e_comment;
    private Integer e_recmmendfid;
    private String e_imgurl;
    private Byte e_state;

    public Integer getE_id() {
        return e_id;
    }

    public void setE_id(Integer e_id) {
        this.e_id = e_id;
    }

    public Integer getE_fid() {
        return e_fid;
    }

    public void setE_fid(Integer e_fid) {
        this.e_fid = e_fid;
    }

    public Integer getE_uid() {
        return e_uid;
    }

    public void setE_uid(Integer e_uid) {
        this.e_uid = e_uid;
    }

    public Integer getE_wid() {
        return e_wid;
    }

    public void setE_wid(Integer e_wid) {
        this.e_wid = e_wid;
    }

    public Integer getE_allrating() {
        return e_allrating;
    }

    public void setE_allrating(Integer e_allrating) {
        this.e_allrating = e_allrating;
    }

    public String getE_comment() {
        return e_comment;
    }

    public void setE_comment(String e_comment) {
        this.e_comment = e_comment;
    }

    public Integer getE_recmmendfid() {
        return e_recmmendfid;
    }

    public void setE_recmmendfid(Integer e_recmmendfid) {
        this.e_recmmendfid = e_recmmendfid;
    }

    public String getE_imgurl() {
        return e_imgurl;
    }

    public void setE_imgurl(String e_imgurl) {
        this.e_imgurl = e_imgurl;
    }

    public Byte getE_state() {
        return e_state;
    }

    public void setE_state(Byte e_state) {
        this.e_state = e_state;
    }
}
