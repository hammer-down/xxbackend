package com.xx.springboot.bean;

import java.sql.Timestamp;
import java.util.Date;

public class TpUser {

    private Integer u_id;
    private String u_loginid;
    private String u_nickname;
    private String u_password;
    private String u_signature;
    private Byte u_sex;
    private String u_email;
    private String u_headportarit;
    private String u_intro;
    private Date u_birthday;
    private Integer u_age;
    private Date u_registertime;
    private String u_loginsite;
    private Integer u_rank;
    private Integer u_score;
    private String u_love1;
    private String u_love2;
    private String u_love3;

    public Integer getU_id() {
        return u_id;
    }

    public void setU_id(Integer u_id) {
        this.u_id = u_id;
    }

    public String getU_loginid() {
        return u_loginid;
    }

    public void setU_loginid(String u_loginid) {
        this.u_loginid = u_loginid;
    }

    public String getU_nickname() {
        return u_nickname;
    }

    public void setU_nickname(String u_nickname) {
        this.u_nickname = u_nickname;
    }

    public String getU_password() {
        return u_password;
    }

    public void setU_password(String u_password) {
        this.u_password = u_password;
    }

    public String getU_signature() {
        return u_signature;
    }

    public void setU_signature(String u_signature) {
        this.u_signature = u_signature;
    }

    public Byte getU_sex() {
        return u_sex;
    }

    public void setU_sex(Byte u_sex) {
        this.u_sex = u_sex;
    }

    public String getU_email() {
        return u_email;
    }

    public void setU_email(String u_email) {
        this.u_email = u_email;
    }

    public String getU_headportarit() {
        return u_headportarit;
    }

    public void setU_headportarit(String u_headportarit) {
        this.u_headportarit = u_headportarit;
    }

    public String getU_intro() {
        return u_intro;
    }

    public void setU_intro(String u_intro) {
        this.u_intro = u_intro;
    }

    public Date getU_birthday() {
        return u_birthday;
    }

    public void setU_birthday(Date u_birthday) {
        this.u_birthday = u_birthday;
    }

    public Integer getU_age() {
        return u_age;
    }

    public void setU_age(Integer u_age) {
        this.u_age = u_age;
    }

    public Date getU_registertime() {
        return u_registertime;
    }

    public void setU_registertime(Date u_registertime) {
        this.u_registertime = u_registertime;
    }

    public String getU_loginsite() {
        return u_loginsite;
    }

    public void setU_loginsite(String u_loginsite) {
        this.u_loginsite = u_loginsite;
    }

    public Integer getU_rank() {
        return u_rank;
    }

    public void setU_rank(Integer u_rank) {
        this.u_rank = u_rank;
    }

    public Integer getU_score() {
        return u_score;
    }

    public void setU_score(Integer u_score) {
        this.u_score = u_score;
    }

    public String getU_love1() {
        return u_love1;
    }

    public void setU_love1(String u_love1) {
        this.u_love1 = u_love1;
    }

    public String getU_love2() {
        return u_love2;
    }

    public void setU_love2(String u_love2) {
        this.u_love2 = u_love2;
    }

    public String getU_love3() {
        return u_love3;
    }

    public void setU_love3(String u_love3) {
        this.u_love3 = u_love3;
    }
}
