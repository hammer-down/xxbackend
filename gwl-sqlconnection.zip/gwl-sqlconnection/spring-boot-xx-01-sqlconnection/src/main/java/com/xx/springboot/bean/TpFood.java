package com.xx.springboot.bean;

public class TpFood {

    private Integer Fid;
    private Integer Fwid;
    private String Fsymbol;
    private String Fname;
    private String Furl;
    private Float Fprice;
    private Float Fdprice;
    private Byte Ftakeout;
    private Integer Fstate;
    private String Fdescription;
    private Float Fhot;
    private Float Fallrating;

    public Integer getFid() {
        return Fid;
    }

    public void setFid(Integer fid) {
        Fid = fid;
    }

    public Integer getFwid() {
        return Fwid;
    }

    public void setFwid(Integer fwid) {
        Fwid = fwid;
    }

    public String getFsymbol() {
        return Fsymbol;
    }

    public void setFsymbol(String fsymbol) {
        Fsymbol = fsymbol;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String fname) {
        Fname = fname;
    }

    public String getFurl() {
        return Furl;
    }

    public void setFurl(String furl) {
        Furl = furl;
    }

    public Float getFprice() {
        return Fprice;
    }

    public void setFprice(Float fprice) {
        Fprice = fprice;
    }

    public Float getFdprice() {
        return Fdprice;
    }

    public void setFdprice(Float fdprice) {
        Fdprice = fdprice;
    }

    public Byte getFtakeout() {
        return Ftakeout;
    }

    public void setFtakeout(Byte ftakeout) {
        Ftakeout = ftakeout;
    }

    public Integer getFstate() {
        return Fstate;
    }

    public void setFstate(Integer fstate) {
        Fstate = fstate;
    }

    public String getFdescription() {
        return Fdescription;
    }

    public void setFdescription(String fdescription) {
        Fdescription = fdescription;
    }

    public Float getFhot() {
        return Fhot;
    }

    public void setFhot(Float fhot) {
        Fhot = fhot;
    }

    public Float getFallrating() {
        return Fallrating;
    }

    public void setFallrating(Float fallrating) {
        Fallrating = fallrating;
    }
}
