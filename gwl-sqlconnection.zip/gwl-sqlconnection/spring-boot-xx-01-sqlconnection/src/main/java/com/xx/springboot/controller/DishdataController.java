package com.xx.springboot.controller;

import com.xx.springboot.bean.Dishdata;
import com.xx.springboot.mapper.DishdataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DishdataController {

    @Autowired
    DishdataMapper dishdataMapper;

    @GetMapping("/dish")
    public Dishdata getDishdata(){
        return dishdataMapper.getDishById();
    }
}
